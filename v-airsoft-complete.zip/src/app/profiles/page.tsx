export default function ProfilesPage() {
  return (
    <main className="min-h-screen bg-green-950 text-white p-6">
      <h1 className="text-3xl font-bold mb-4">🪖 Profile</h1>
      <p className="text-green-300">Hier kommt bald dein Inhalt rein...</p>
    </main>
  );
}