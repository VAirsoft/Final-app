import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-green-900 text-white font-mono p-4 text-center">
      <Image src="/logo.jpg" alt="V Airsoft Logo" width={120} height={120} className="mx-auto mb-4" />
      <h1 className="text-4xl font-bold mb-4">V AIRSOFT TEAM</h1>
      <nav className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center mb-8">
        <Link href="/gallery"><button className="bg-green-700 p-4 rounded">📸 Galerie</button></Link>
        <Link href="/fields"><button className="bg-green-700 p-4 rounded">📍 Spielfelder</button></Link>
        <Link href="/profiles"><button className="bg-green-700 p-4 rounded">🪖 Profile</button></Link>
        <Link href="/loadouts"><button className="bg-green-700 p-4 rounded">🎒 Loadouts</button></Link>
      </nav>
      <p className="text-green-300 text-sm">Willkommen, Soldat. Wähle deinen Einsatzbereich.</p>
    </main>
  );
}